<html>
<body>
<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/libconfig.inc.php';
require_once LIB.'admin/errors.php';
?>
</body>
</html>