<div id="nav">
<a href="?action=view&amp;page=<?php echo $data['page']; ?>">View</a> |
<a href="?action=chart&amp;page=<?php echo $data['page']; ?>">Charts</a> |
<a href="?action=refer&amp;page=<?php echo $data['page']; ?>">Referrers</a> |
<a href="?action=reset&amp;page=<?php echo $data['page']; ?>">Reset</a>
</div>