<?php
require_once('general.php');
require_once('database.php');
require_once('functions_cache.php');
function is_image($file) {
	return getimagesize($file);
}
function image_create($file, &$info = null) {
	if ($info == null)
		$info = getimagesize($file);
	$mime = explode('/', $info['mime']);
	$src = null;
	if ($mime[1] == 'jpeg' || $mime[1] == 'jpg') {
		$src = imagecreatefromjpeg($file);
	} else if ($mime[1] == 'gif') {
		$src = imagecreatefromgif($file);
	} else if ($mime[1] == 'png') {
		$src = imagecreatefrompng($file);
	}
	return $src;
}
function _image_avatar_pet($user_id, $pet_id, $image_id, $filename, $selx=0, $sely=0, $selwidth=0, $selheight=0) {
	$info = getimagesize(root_dir."/$user_id/$pet_id/{$image_id}_$filename");
	$src = image_create(root_dir."/$user_id/$pet_id/{$image_id}_$filename", $info);
	if ($selwidth==0 && $selheight == 0) {
		$selwidth = $info[0];
		$selheight = $info[1];
	} else if ($selheight == 0) {
		$selheight = $info[1]-$sely;
	} else if ($selwidth == 0) {
		$selwidth = $info[0]-$selx;
	}
	if ($selwidth < 100 && $selheight < 100) {
		$width = $selwidth;
		$height = $selheight;
		$x = (100-$selwidth)/2;
		$y = (100-$selheight)/2;
	} else {
		$x = 0;
		$y = 0;
		$ratio = $selwidth/$selheight;
		if ($selwidth > $selheight) {
			$width = 100;
			$height = 100/$ratio;
			$y = (100-$height)/2;
		} else {
			$width = 100*$ratio;
			$height = 100;
			$x = (100-$width)/2;
		}
	}
	$dest = imagecreatetruecolor(100, 100);
	$background = imagecolorallocate($dest, 255,255,255);
	imagefill($dest, 0, 0, $background);
	//$dest = imagecreatetruecolor($width, $height);
	if (imagecopyresampled($dest, $src, $x, $y, $selx, $sely, $width, $height, $selwidth, $selheight)) {
	//if (imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $info[0], $info[1])) {
		imagedestroy($src);
		//$filename = basename($file);
		$file = root_dir."/$user_id/$pet_id/avatar.jpg";
		$color = imagecolorallocate($dest, 0, 114, 187);
		imagerectangle($dest, 0,0,$width-1, $height-1, $color);
		imagejpeg($dest, $file);
		imagedestroy($dest);
		return true;
	} else {
		imagedestroy($src);
		imagedestroy($dest);
		return false;
	}
}
function _image_avatar_album($user_id, $pet_id, $album_id, $image_id, $filename, $selx=0, $sely=0, $selwidth=0, $selheight=0) {
	$info = getimagesize(root_dir."/$user_id/$pet_id/{$image_id}_$filename");
	$src = image_create(root_dir."/$user_id/$pet_id/{$image_id}_$filename", $info);
	if ($selwidth==0 && $selheight == 0) {
		$selwidth = $info[0];
		$selheight = $info[1];
	} else if ($selheight == 0) {
		$selheight = $info[1]-$sely;
	} else if ($selwidth == 0) {
		$selwidth = $info[0]-$selx;
	}
	if ($selwidth < 100 && $selheight < 100) {
		$width = $selwidth;
		$height = $selheight;
		$x = (100-$selwidth)/2;
		$y = (100-$selheight)/2;
	} else {
		$x = 0;
		$y = 0;
		$ratio = $selwidth/$selheight;
		if ($selwidth > $selheight) {
			$width = 100;
			$height = 100/$ratio;
			$y = (100-$height)/2;
		} else {
			$width = 100*$ratio;
			$height = 100;
			$x = (100-$width)/2;
		}
	}
	$dest = imagecreatetruecolor(100, 100);
	$background = imagecolorallocate($dest, 255,255,255);
	imagefill($dest, 0, 0, $background);
	//$dest = imagecreatetruecolor($width, $height);
	if (imagecopyresampled($dest, $src, $x, $y, $selx, $sely, $width, $height, $selwidth, $selheight)) {
	//if (imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $info[0], $info[1])) {
		imagedestroy($src);
		//$filename = basename($file);
		$file = root_dir."/$user_id/$pet_id/$album_id/avatar.jpg";
		$color = imagecolorallocate($dest, 0, 114, 187);
		imagerectangle($dest, $x,$y,$x+$width, $y+$height, $color);
		if (imagejpeg($dest, $file)) {
			imagedestroy($dest);
			return true;
		} else {
			imagedestroy($dest);
			return false;
		}
	} else {
		imagedestroy($src);
		imagedestroy($dest);
		return false;
	}
}
function image_avatar($user_id, $pet_id, $album_id = null, $image_id, $filename, $x=0, $y=0, $width=0, $height=0) {
	if ($user_id) {
		if ($pet_id) {
			if ($album_id) {
				return _image_avatar_album($user_id, $pet_id, $album_id, $image_id, $filename, $x, $y, $width, $height);
			} else {
				return _image_avatar_pet($user_id, $pet_id,$image_id, $filename, $x, $y, $width, $height);
			}
		}
	}
	return false;
}
function image_thumbnail($file, $info = null) {
	$src = image_create($file, $info);
	if (!$src)
		return false;
	if ($info[0] < 100 && $info[1] < 100) {
		$width = $info[0];
		$height = $info[1];
		//$x = (100-$info[0])/2;
		//$y = (100-$info[1])/2;
	} else {
		//$x = 0;
		//$y = 0;
		$ratio = $info[0]/$info[1];
		if ($info[0] > $info[1]) {
			$width = 100;
			$height = 100/$ratio;
			//$y = (100-$height)/2;
		} else {
			$width = 100*$ratio;
			$height = 100;
			//$x = (100-$width)/2;
		}
	}
	//$dest = imagecreatetruecolor(100, 100);
	//$background = imagecolorallocate($dest, 255,255,255);
	//imagefill($dest, 0, 0, $background);
	$dest = imagecreatetruecolor($width, $height);
	//if (imagecopyresampled($dest, $src, $x, $y, 0, 0, $width, $height, $info[0], $info[1])) {
	if (imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $info[0], $info[1])) {
		imagedestroy($src);
		$filename = basename($file);
		$file = substr($file, 0, strlen($file)-strlen($filename)).'thumb_'.$filename;
		$color = imagecolorallocate($dest, 0, 114, 187);
		imagerectangle($dest, 0,0,$width-1, $height-1, $color);
		$mime = explode('/', $info['mime']);
		if ($mime[1] == 'jpeg' || $mime[1] == 'jpg') {
			imagejpeg($dest, $file);
		} else if ($mime[1] == 'gif') {
			imagegif($dest, $file);
		} else if ($mime[1] == 'png') {
			imagepng($dest, $file);
		} else {
			echo 'Unsupported type: '.$mime[1];
			imagedestroy($dest);
			return false;
		}
		imagedestroy($dest);
		return true;
	} else {
		imagedestroy($src);
		imagedestroy($dest);
		return false;
	}
}
function image_crop($file, $x, $y, $width, $height, $info = null) {
	$src = image_create($file, $info);
	if (!$src)
		return false;
	$dest = imagecreatetruecolor($width, $height);
	if (imagecopy($dest, $src, 0, 0,$x, $y, $width, $height)) {
		imagedestroy($src);
		$color = imagecolorallocate($dest, 0, 114, 187);
		imagerectangle($dest, 0,0,$width-1, $height-1, $color);
		$mime = explode('/', $info['mime']);
		if ($mime[1] == 'jpeg' || $mime[1] == 'jpg') {
			imagejpeg($dest, $file);
		} else if ($mime[1] == 'gif') {
			imagegif($dest, $file);
		} else if ($mime[1] == 'png') {
			imagepng($dest, $file);
		} else {
			echo 'Unsupported type: '.$mime[1];
			imagedestroy($dest);
			return false;
		}
		imagedestroy($dest);
		return true;
	} else {
		imagedestroy($src);
		imagedestroy($dest);
		return false;
	}
	//bool imagecopyresized ( resource $dst_image , resource $src_image , int $dst_x , int $dst_y , int $src_x , int $src_y , int $dst_w , int $dst_h , int $src_w , int $src_h )
}
function image_resize($file, $new_width = null, $new_height = null, $info = null) {
	if ($new_width == null && $new_height == null) return false;
	$src = image_create($file, $info);
	if (!$src)
		return false;
	$ratio = $info[0]/$info[1];
	if ($new_width != null && $new_height != null) {
		$width = $new_width;
		$height = $new_height;
	} else {
		if ($new_width != null) {
			$width = $new_width;
			$height = $width/$ratio;
		} else {
			$height = $new_height;
			$width = $height*$ratio;
		}
	}
	$dest = imagecreatetruecolor($width, $height);
	if (imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $info[0], $info[1])) {
		imagedestroy($src);
		$color = imagecolorallocate($dest, 0, 114, 187);
		imagerectangle($dest, 0,0,$width-1, $height-1, $color);
		$mime = explode('/', $info['mime']);
		if ($mime[1] == 'jpeg' || $mime[1] == 'jpg') {
			imagejpeg($dest, $file);
		} else if ($mime[1] == 'gif') {
			imagegif($dest, $file);
		} else if ($mime[1] == 'png') {
			imagepng($dest, $file);
		} else {
			echo 'Unsupported type: '.$mime[1];
			imagedestroy($dest);
			return false;
		}
		imagedestroy($dest);
		return true;
	} else {
		imagedestroy($src);
		imagedestroy($dest);
		return false;
	}
}
function image_add($user_id, $pet_id, $album_id, &$name) {
	$db = db_get_connection();
	$res = mysql_query("SELECT image_id FROM images WHERE user_id=0 AND pet_id=0 AND album_id=0 LIMIT 1,1", $db);
	if (!$res || mysql_num_rows($res)==0) {
		$query = "INSERT INTO images VALUES (0, $user_id, $album_id, $pet_id, NOW(), '$name', null)";
	} else {
		$row = mysql_fetch_array($res);
		$query = "UPDATE images SET user_id=$user_id, pet_id=$pet_id, album_id=$album_id, filename='$name' WHERE image_id=".$row['image_id'];
	}
	if (mysql_query($query, $db)) {
		$specs = is_image(root_dir."/$user_id/$pet_id/$name");
		$res = mysql_query("select image_id from images where filename='$name' AND user_id=$user_id AND pet_id=$pet_id", $db);
		$row = mysql_fetch_array($res);
		rename(root_dir."/$user_id/$pet_id/$name", root_dir."/$user_id/$pet_id/".$row['image_id']."_$name");
		$name = $row['image_id']."_$name";
		$_SESSION['upload']['files'][] = array("/$user_id/$pet_id/thumb_$name", $row['image_id']);
		image_thumbnail(root_dir."/$user_id/$pet_id/$name", $specs);
		if ($specs[0] > 540) {
			image_resize(root_dir."/$user_id/$pet_id/$name", 540, null, $specs);
		}
		$error = cache_page($user_id, $pet_id, $album_id, $row['image_id']);
		$error .= cache_page($user_id, $pet_id, $album_id);
		$error .= cache_page($user_id, $pet_id);
		if ($error) echo $error;
		return true;
	} else {
		echo mysql_error();
		return false;
	}
}
function image_delete($user_id, $pet_id, $album_id, $image_id) {
	$db = db_get_connection();
	$filename = getSimpleData('filename', 'images', "image_id=$image_id");
	if (mysql_query("UPDATE images SET user_id=0, album_id=0, pet_id=0, filename='', image_desc=null WHERE image_id=$image_id", $db)) {
		$files = scandir(root_dir."/$user_id/$pet_id/$album_id/");
		foreach ($files as $file) {
			if ($file == $image_id.'.php' || str_starts_with($image_id.'_', $file)) {
				@unlink(root_dir."/$user_id/$pet_id/$album_id/$file");
			}
		}
		@unlink(root_dir."/$user_id/$pet_id/{$image_id}_$filename");
		@unlink(root_dir."/$user_id/$pet_id/thumb_{$image_id}_$filename");
	}
}
function image_compact_db() {
	/*
	fetch all images
	create temporary table
	c
	*/
}
?>