<?php
/**
 * @author Kenneth Pierce kcpiercejr@gmail.com
 */
//require_once 'class_CustomException.php';
PackageManager::requireClassOnce('lib.error.CustomException');

class IOException extends CustomException {

}
?>