<?php
/**
 * @author Kenneth Pierce kcpiercejr@gmail.com
 */


/**
 * Class to build a table backed by a SQL table.
 * Includes column sorting.
 *
 * @author Kenneth Pierce
 */
class sql_table {
	private $table = '';
	private $select_columns = array();
	private $hidden_columns = array();
	private $aliases_columns = array();
	private $column_format = array();
	/**
	 * Sets the table to be queried.
	 * @param string $table
	 */
	public function setTable($table) {
		$this->table = $table;
	}
	/**
	 * Adds a hidden column. It is in the select statement, but not displayed.
	 * @param string $column The column name.
	 */
	public function addHiddenColumn($column) {
		$this->select_columns[] = $column;
		$this->hidden_columns[] = $column;
	}
	/**
	 * Adds several hidden columns.
	 * @param array $columns Column list.
	 */
	public function addHiddenColumns(array $columns) {
		$this->select_columns = array_merge($this->select_columns, $columns);
		$this->hidden_columns = array_merge($this->hidden_columns, $columns);
	}
	/**
	 * Adds a column to the select query.
	 * @param string $column The table column
	 * @param string $alias The name to be displayed.
	 */
	public function addColumn($column, $alias = null) {
		$this->select_columns[] = $column;
		if ($alias)
			$this->aliases_columns[$column] = $alias;
	}
	/**
	 * Adds the columns to the select query.
	 * @param array $columns Table columns.
	 * @param array $aliases Display columns.
	 */
	public function addColumns(array $columns, array $aliases) {
		$merged = array_combine($columns, $aliases);
		foreach ($merged as $column => $alias)
			$this->addColumn($column, $alias);
	}
	/**
	 * Sets the format/content for the column. Columns can be
	 * referenced by $column.
	 * @param string $column The column name.
	 * @param string $format The column content.
	 */
	public function setColumnFormat($column, $format) {
		$this->column_format[$column] = $format;
	}
	/**
	 * Queries and returns the table.
	 * @param resource $db MySQL database connection.
	 * @param string $conditions SQL query conditions.
	 * @param string $extra Extra appended to the link.
	 * @return string The table.
	 */
	public function printTable($db, $conditions = null, $extra = '') {
		$buf = '';
		$row_count = 0;
		$start = 0;
		$numrows = 10;
		$sort = null;
		$sortDir = 'ASC';
		$dir = 'up';
		$pageLinks = '';
		$shown_columns = array_diff($this->select_columns, $this->hidden_columns);

		if (isset($_REQUEST['start'])) {
			$start = $_REQUEST['start'];
		}
		if (isset($_REQUEST['numrows'])) {
			$numrows = $_REQUEST['numrows'];
			if ($numrows > 100) {
				$numrows = 100;
			} else if ($numrows < 1) {
				$numrows = 10;
			}
		}
		/*if (isset($_REQUEST['letter']) && !empty($_REQUEST['letter'])) {
			if (ereg('^[a-z]?$', $_REQUEST['letter']))
			$letter = $_REQUEST['letter'];
		}*/
		if (isset($_REQUEST['sort']) && !empty($_REQUEST['sort'])) {
			$sort = $_REQUEST['sort'];
			if (isset($_REQUEST['dir'])) {
				if ($_REQUEST['dir'] == 'down') {
					$sortDir = 'DESC';
				} else {
					$sortDir = 'ASC';
				}
				$dir = $_REQUEST['dir'];
			}
		}
		if ($sort==null) {
			$sort = $shown_columns[0];
		}
		$sql = 'SELECT SQL_CACHE ';
		$sql .= implode(',', $this->select_columns);
		if ($conditions == '' || $conditions == null)
			$sql .= " FROM $this->table";
		else
			$sql .= " FROM $this->table WHERE $conditions";

		$sql .= " ORDER BY $sort $sortDir";
		$res = mysql_query($sql, $db);
		if (!$res) {
			$err = logError(mysql_error(), $sql);
			printError('Database error: '.$err);
		}
		$row_count=mysql_num_rows($res);
		if ($row_count==0) {
			return 'Nothing found.';
		}
		//mysql_data_seek($res,$start);
		/********************
		 ********************
		 ********************/
		?>
		<form method="get">
		Results per page:
			<select name="numrows">
		<?php for ($i = 10; $i < 101; $i+=10) {?>
				<option value="<?php echo $i; ?>" <?php echo ($i == $numrows)?'selected="selected"':''; ?>><?php echo $i; ?></option>
		<?php }?>
			</select>
			<?php
				foreach($_REQUEST as $key=>$value) {
					if ($key == 'numrows') continue;
					echo "<input type=\"hidden\" name=\"$key\" value=\"$value\" />";
				}
			?>
		<input type="submit" value="Update" />
		</form>
		<?php
		$pageLinks = getPages($row_count, $start, $numrows, "&amp;sort=$sort&amp;dir=".$dir.$extra);
		$buf .= "<div>$pageLinks</div>";
		$buf .= '<table>';
		/********************
		 ****TITLES**********
		 ********************/
		// DIR CHANGES USES HERE!! IT NO LONGER CONTAINS THE DIRECTION STRING
		$buf .= "\n<tr>\n";
		$baseurl = '';//$_SERVER['PHP_SELF'];

		foreach($shown_columns as $column) {
			$display = isset($this->aliases_columns[$column])?$this->aliases_columns[$column]:$column;
			$buf .= "\t<th><a href=\"".$baseurl.'?sort='.$column;
			$dir = false; // false is up
			if ($sort==$column) {
				if ($sortDir=='ASC') {
					$buf .= '&amp;dir=down';
					$dir = true;
				} else {
					$buf .= '&amp;dir=up';
				}
				$buf .= '&amp;numrows='.$numrows.$extra.'">'.$display;
				if ($dir) {
					$buf .= '&nbsp;<img src="/images/arrow_down.png" />';
				} else {
					$buf .= '&nbsp;<img src="/images/arrow_up.png" />';
				}
			} else {
				$buf .= '&amp;dir=down&amp;numrows='.$numrows.$extra.'">'.$display;
			}
			$buf .= "</a></th>\n";
		}
		$buf .= '</tr>';
		/********************
		 ***ROWS*************
		 ********************/
		 /*
		$select_columns = array();
		$hidden_columns = array();
		$aliases_columns = array();
		$column_format = array();
		*/
		if (mysql_num_rows($res) > 0) {
			while ($row = mysql_fetch_array($res)) {
				if ($numrows == 0) break;
				$rowBuf = "<tr>\n";
				foreach($shown_columns as $column) {
					$rowBuf .= "\t<td>";
					if (isset($this->column_format[$column]))
						$rowBuf .= str_replace('$'.$column.'$',$row[$column],$this->column_format[$column]);
					else
						$rowBuf .= $row[$column];
					$rowBuf .= "</td>\n";
				}
				$buf .= $rowBuf."</tr>\n";
				$numrows--;
			}
		}
		$buf .= '</table>';
		$buf .= "<div>$pageLinks</div>";
		$buf .= '<span style="font-size:smaller;">'.getElapsed('query').' seconds</span>';
		return $buf;
	}
}// -- end class sql_table


// <tr><td><a href="/index.php?jid=$jid$">$title</a></td><td><img src="/images/$rating$.jpg" /></td></tr>
//URL tokens: sort, dir, numrows, start
function createTable($table, $columns, $displayColumns, $rowFormat, $conditions, $extra = '', $db) {
	$buf = '';
	$row_count = 0;
	$start = 0;
	$numrows = 10;
	$sort = null;
	$sortDir = 'ASC';
	$dir = 'up';
	$pageLinks = '';
	$usedColumns = array();
	/********************
	 ********************
	 ********************/

	if (isset($_REQUEST['start'])) {
		$start = $_REQUEST['start'];
	}
	if (isset($_REQUEST['numrows'])) {
		$numrows = $_REQUEST['numrows'];
		if ($numrows > 100) {
			$numrows = 100;
		} else if ($numrows < 1) {
			$numrows = 10;
		}
	}
	/*if (isset($_REQUEST['letter']) && !empty($_REQUEST['letter'])) {
		if (ereg('^[a-z]?$', $_REQUEST['letter']))
		$letter = $_REQUEST['letter'];
	}*/
	if (isset($_REQUEST['sort']) && !empty($_REQUEST['sort'])) {
		$sort = $_REQUEST['sort'];
		if (isset($_REQUEST['dir'])) {
			if ($_REQUEST['dir'] == 'down') {
				$sortDir = 'DESC';
			} else {
				$sortDir = 'ASC';
			}
			$dir = $_REQUEST['dir'];
		}
	}
	if ($sort==null) {
		foreach($displayColumns as $key=>$value) {
			if (is_array($value))
				if (isset($value[2]) && $value[2]) {
					$sort = $key;
					break;
				}
		}
	}
	$sql = 'SELECT SQL_CACHE ';
	$sql .= implode(',', $columns);
	if ($conditions == '' || $conditions == null)
		$sql .= " FROM $table";
	else
		$sql .= " FROM $table WHERE $conditions";

	$sql .= " ORDER BY $sort $sortDir";
	$res = mysql_query($sql, $db);
	if (!$res) {
		$err = mysql_error();
		printError('Database error: '.$err);
	}
	$row_count=mysql_num_rows($res);
	if ($row_count==0) {
		return 'No tools found that match your criteria.';;
	}
	//mysql_data_seek($res,$start);
	/********************
	 ********************
	 ********************/
	?>
	<form method="get">
	Results per page:
		<select name="numrows">
	<?php for ($i = 10; $i < 101; $i+=10) {?>
			<option value="<?php echo $i; ?>" <?php echo ($i == $numrows)?'selected="selected"':''; ?>><?php echo $i; ?></option>
	<?php }?>
		</select>
		<?php
			foreach($_REQUEST as $key=>$value) {
				if ($key == 'numrows') continue;
				echo "<input type=\"hidden\" name=\"$key\" value=\"$value\" />";
			}
		?>
	<input type="submit" value="Update" />
	</form>
	<?php
	$pageLinks = getPages($row_count, $start, $numrows, "&amp;sort=$sort&amp;dir=".$dir.$extra);
	$buf .= "<div>$pageLinks</div>";
	$buf .= '<table>';
	/********************
	 ****TITLES**********
	 ********************/
	// DIR CHANGES USES HERE!! IT NO LONGER CONTAINS THE DIRECTION STRING
	$buf .= '<tr>';
	$baseurl = '';//$_SERVER['PHP_SELF'];
	foreach($displayColumns as $column=>$display) {
		$buf .= '<th><a href="'.$baseurl.'?sort='.$column;
		$dir = false; // false is up
		if ($sort==$column) {
			if ($sortDir=='ASC') {
				$buf .= '&amp;dir=down';
				$dir = true;
			} else {
				$buf .= '&amp;dir=up';
			}
			if (is_array($display))
				$buf .= '&amp;numrows='.$numrows.$extra.'">'.$display[0];
			else
				$buf .= '&amp;numrows='.$numrows.$extra.'">'.$display;
			if ($dir) {
				$buf .= '&nbsp;<img src="arrow_down.png" />';
			} else {
				$buf .= '&nbsp;<img src="arrow_up.png" />';
			}
		} else {
			if (is_array($display))
				$buf .= '&amp;dir='.$display[1].'&amp;numrows='.$numrows.$extra.'">'.$display[0];
			else
				$buf .= '&amp;dir=down&amp;numrows='.$numrows.$extra.'">'.$display;
		}
		$buf .= '</a></th>';
	}
	$buf .= '</tr>';
	/********************
	 ***ROWS*************
	 ********************/
	foreach($columns as $column) {
		if (strpos($rowFormat, '$'.$column.'$')) {
			$usedColumns[] = $column;
		}
	}
	if (mysql_num_rows($res) > 0) {
		while ($row = mysql_fetch_array($res)) {
			if ($numrows == 0) break;
			$rowBuf = $rowFormat;
			foreach($usedColumns as $column) {
				$rowBuf = str_replace('$'.$column.'$',$row[$column],$rowBuf);
			}
			$buf .= $rowBuf;
			$numrows--;
		}
	}
	$buf .= '</table>';
	$buf .= "<div>$pageLinks</div>";
	$buf .= '<span style="font-size:smaller;">'.getElapsed('query').' seconds</span>';
	return $buf;
} // -- createTable --
function getPages($totalRows, $currentRow, $rowsPerPage, $extra = '') {
	$cPages = ceil($totalRows/$rowsPerPage);
	if ($cPages == 1) { return ' '; }
	if (isset($_REQUEST['start']))
		$start = $_REQUEST['start'];
	else
		$start = 0;
	$pageLinks = '';
	if ($start > 0) {
		$pageLinks .= '<a href="?start=0&amp;numrows='.$rowsPerPage.$extra.'"><img src="/images/resultset_first.png" /></a>';
		$pageLinks .= ' <a href="?start='.($currentRow-$rowsPerPage).'&amp;numrows='.$rowsPerPage.$extra.'"><img src="/images/resultset_previous.png" /></a>';
	}
	$page = $currentRow/$rowsPerPage;
	$cPage = $page;
	$topPage = $page+2;
	$page -= 2;
	if ($page < 0) { $page = 0; }
	for (; $page <= $topPage && $page < $cPages; $page++) {
		if ($page == $cPage) {
			$pageLinks .= ' '.($page+1);
		} else {
			$pageLinks .= ' <a href="?start='.($page*$rowsPerPage).'&amp;numrows='.$rowsPerPage.$extra.'">'.($page+1).'</a>';
		}
	}

	if ($topPage-1 < $cPages) {
		if ($topPage < $cPages-1)
			$pageLinks .= ' ... <a href="?start='.(($cPages-1)*$rowsPerPage).'&amp;numrows='.$rowsPerPage.$extra.'">'.$cPages.'</a>';
		$pageLinks .= ' <a href="?start='.(($topPage-1)*$rowsPerPage).'&amp;numrows='.$rowsPerPage.$extra.'"><img src="/images/resultset_next.png" /></a>';
		$pageLinks .= ' <a href="?start='.(($cPages-1)*$rowsPerPage).'&amp;numrows='.$rowsPerPage.$extra.'"><img src="/images/resultset_last.png" /></a>';
	}
	return $pageLinks;
} // -- getPages --
?>