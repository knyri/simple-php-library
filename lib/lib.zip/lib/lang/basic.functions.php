<?php
function isEmpty(array $arr) {
	foreach ($arr as $ele) {
		if (!empty($ele)) return false;
	}
	return true;
}
?>