<?php
/**
 * @author Kenneth Pierce kcpiercejr@gmail.com
 */

/**
 *
 * @author Martin Sweeny
 * @version 2010.0617
 *
 * returns formatted number of bytes.
 * two parameters: the bytes and the precision (optional).
 * if no precision is set, function will determine clean
 * result automatically.
 * @param b bytes
 * @param p precision (0 being Bytes and 8 being YB)
 * @return The formatted output
 **/
function formatBytes($b,$p = null) {
    $units = array("B","kB","MB","GB","TB","PB","EB","ZB","YB");
    $c=0;
    if(!$p && $p !== 0) {
        foreach($units as $k => $u) {
            if(($b / pow(1024,$k)) >= 1) {
                $r["bytes"] = $b / pow(1024,$k);
                $r["units"] = $u;
                $c++;
            }
        }
        return number_format($r["bytes"],2) . " " . $r["units"];
    } else {
        return number_format($b / pow(1024,$p)) . " " . $units[$p];
    }
}
/**
 * Lists the files in the supplied directory. One file per line.
 * Creates a direct link.
 * @param string $dir Target directory
 * @param string $relativeTo Directory of the source page
 */
function listFiles($dir = '.', $relativeTo = '.', $usecounter = false) {
	$sdir = substr($dir, strlen($relativeTo));
	$pdir = opendir($dir);
	$files = array();
	while ($file = readdir($pdir)) {
		if (!is_dir($dir.$file)) {
			$files[] = $file;
		}
	}
	sort($files);
	?>
		<table>
			<tr><th>icon</th><th>name</th><th>size</th></tr>
	<?php
	foreach($files as $file) {
		?>
			<tr>
				<td><?php
				$pos = strpos($file, '.');
				if ($pos===FALSE) {
					echo " ";
				} else {
					?><img src="/images/icons/file/<?php echo substr($file, $pos+1); ?>.png" alt="" /><?php
				}
				?></td>
				<td>
					<a href="<?php echo ($usecounter?'/downloadcounter.php?url=':'').$sdir.$file; ?>"><?php echo $file; ?></a>
				</td>
				<td><?php echo formatBytes(@filesize($dir.$file)); ?></td>
			</tr>
	<?php
	}
	?>
	</table>
	<?php
}
?>