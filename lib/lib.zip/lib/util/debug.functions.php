<?php
/**
 * @author Kenneth Pierce kcpiercejr@gmail.com
 */

/**
 * Dumps the session variable.
 */
function dump_session() {
	print_var($_SESSION);
}
/**
 * Dumps the variable to the ouput. (for HTML pages)
 * @param unknown_type $var
 */
function print_var($var) {
	echo '<p><pre>';
	var_dump($var);
	echo '</p></pre>';
}
?>