<?php
/**
 * @author Kenneth Pierce kcpiercejr@gmail.com
 */

/**
 * Creates a select element from a mysql result set where the first field is the value and the
 * second field is the display.
 * @param resource $result The first field is the value, the second field is the display.
 * @param array $attrib An array of 'key'=>'value' mappings that will be added to the attribute list.
 * @param string|int $value Defaults to null. If left blank it will be set to the value found in $_GET or $_POST.
 * @deprecated
 */
function form_select_mysqlresult($result, array $attrib, $value=null) {
	form_create_select_mysql($result, $attrib, $value);
}
/**
 * Gets the value of at $index in $_GET or $_POST.
 * <em>Checks $_POST first.</em>
 * If neither have the value then $default is returned.
 * @param mixed $index
 * @param mixed $default
 * @return mixed The value found in $_GET or $_POST or $default if neither had the index defined.
 */
function form_get($index, $default=null) {
	if (isset($_POST[$index])) {
		if (empty($_POST[$index])) return $default;
		return $_POST[$index];
	}
	if (isset($_GET[$index])) {
		if (empty($_GET[$index])) return $default;
		return $_GET[$index];
	}
	return $default;
}
/**
 * Creates a select element from a mysql result set where the first field is the value and the
 * second field is the display.
 * @param resource $result The first field is the value, the second field is the display.
 * @param array $attrib An array of 'key'=>'value' mappings that will be added to the attribute list.
 * @param string|int $selected Defaults to null. If left blank it will be set to the value found in $_GET or $_POST.
 */
function form_create_select_mysql($result, array $attrib, $selected=null) {
	if (!isset($attrib['name'])) {
		throw new IllegalArgumentException('name must be set in the attribute list');
	}
	if ($selected===null)
		$selected = form_get($attrib['name']);

	echo '<select';
	foreach ($attrib as $key => $value) {
		echo " $key=\"$value\"";
	}
	echo '>'.EOL;
	if ($selected===null) {
		$row = mysql_fetch_array($result);
?>	<option value="<?php echo $row[0]; ?>" selected="selected"><?php echo $row[1]; ?></option><?php
		echo EOL;
		while ($row = mysql_fetch_array($result)) {
?>	<option value="<?php echo $row[0]; ?>"><?php echo $row[1]; ?></option><?php
			echo EOL;
		}
	} else {
		while ($row = mysql_fetch_array($result)) {
?>	<option value="<?php echo $row[0]; ?>"<?php if ($row[0]==$selected) echo ' selected="selected"'; ?>><?php echo $row[1]; ?></option><?php
			echo EOL;
		}
	}
	echo '</select>'.EOL;
}
/**
 * Takes the array and outputs a hidden form element for each
 * array element. The array must be 'name'=>'value' format.
 * @param array $list
 */
function form_create_hidden_from_array(array $list) {
	foreach ($list as $name => $value) {
		echo '<input type="hidden" name="'.$name.'" value="'.$value.'" />'."\n";
	}
}
/**
 * Outputs a date element.
 * Element names are name[month], name[day], name[year]
 * @param string $name suffix for the elements.
 * @param string $date A unix date stamp( year-month-day ) or an array('day'=>day, 'month'=>month, 'year'=>year). May be null.
 */
function form_create_date($name, $date=null) {
	$year = 0; $month = 1; $day = 1;
	if ($date===null) {
		$date = form_get($name);
	}

	if (is_array($date)) {
		$date = array_map('intval', $date);
		$year = $date['year'];
		$month = $date['month'];
		$day = $date['day'];
	} elseif (!empty($date)) {
		list($year, $month, $day) = array_map('intval',explode('-', $date));
	}
	?>
	<select name="<?php echo $name; ?>[month]" >
	<option value="01"<?php echo $date[1]==1?'selected="selected"':''; ?>>Jan</option>
	<option value="02"<?php echo $date[1]==2?'selected="selected"':''; ?>>Feb</option>
	<option value="03"<?php echo $date[1]==3?'selected="selected"':''; ?>>Mar</option>
	<option value="04"<?php echo $date[1]==4?'selected="selected"':''; ?>>Apr</option>
	<option value="05"<?php echo $date[1]==5?'selected="selected"':''; ?>>May</option>
	<option value="06"<?php echo $date[1]==6?'selected="selected"':''; ?>>Jun</option>
	<option value="07"<?php echo $date[1]==7?'selected="selected"':''; ?>>Jul</option>
	<option value="08"<?php echo $date[1]==8?'selected="selected"':''; ?>>Aug</option>
	<option value="09"<?php echo $date[1]==9?'selected="selected"':''; ?>>Sep</option>
	<option value="10"<?php echo $date[1]==10?'selected="selected"':''; ?>>Oct</option>
	<option value="11"<?php echo $date[1]==11?'selected="selected"':''; ?>>Nov</option>
	<option value="12"<?php echo $date[1]==12?'selected="selected"':''; ?>>Dec</option>
	</select>
	<select name="<?php echo $name; ?>[day]" >
	<option value="01"<?php echo $date[2]==1?'selected="selected"':''; ?>>1</option>
	<option value="02"<?php echo $date[2]==2?'selected="selected"':''; ?>>2</option>
	<option value="03"<?php echo $date[2]==3?'selected="selected"':''; ?>>3</option>
	<option value="04"<?php echo $date[2]==4?'selected="selected"':''; ?>>4</option>
	<option value="05"<?php echo $date[2]==5?'selected="selected"':''; ?>>5</option>
	<option value="06"<?php echo $date[2]==6?'selected="selected"':''; ?>>6</option>
	<option value="07"<?php echo $date[2]==7?'selected="selected"':''; ?>>7</option>
	<option value="08"<?php echo $date[2]==8?'selected="selected"':''; ?>>8</option>
	<option value="09"<?php echo $date[2]==9?'selected="selected"':''; ?>>9</option>
	<option value="10"<?php echo $date[2]==10?'selected="selected"':''; ?>>10</option>
	<option value="11"<?php echo $date[2]==11?'selected="selected"':''; ?>>11</option>
	<option value="12"<?php echo $date[2]==12?'selected="selected"':''; ?>>12</option>
	<option value="13"<?php echo $date[2]==13?'selected="selected"':''; ?>>13</option>
	<option value="14"<?php echo $date[2]==14?'selected="selected"':''; ?>>14</option>
	<option value="15"<?php echo $date[2]==15?'selected="selected"':''; ?>>15</option>
	<option value="16"<?php echo $date[2]==16?'selected="selected"':''; ?>>16</option>
	<option value="17"<?php echo $date[2]==17?'selected="selected"':''; ?>>17</option>
	<option value="18"<?php echo $date[2]==18?'selected="selected"':''; ?>>18</option>
	<option value="19"<?php echo $date[2]==19?'selected="selected"':''; ?>>19</option>
	<option value="20"<?php echo $date[2]==20?'selected="selected"':''; ?>>20</option>
	<option value="21"<?php echo $date[2]==21?'selected="selected"':''; ?>>21</option>
	<option value="22"<?php echo $date[2]==22?'selected="selected"':''; ?>>22</option>
	<option value="23"<?php echo $date[2]==23?'selected="selected"':''; ?>>23</option>
	<option value="24"<?php echo $date[2]==24?'selected="selected"':''; ?>>24</option>
	<option value="25"<?php echo $date[2]==25?'selected="selected"':''; ?>>25</option>
	<option value="26"<?php echo $date[2]==26?'selected="selected"':''; ?>>26</option>
	<option value="27"<?php echo $date[2]==27?'selected="selected"':''; ?>>27</option>
	<option value="28"<?php echo $date[2]==28?'selected="selected"':''; ?>>28</option>
	<option value="29"<?php echo $date[2]==29?'selected="selected"':''; ?>>29</option>
	<option value="30"<?php echo $date[2]==30?'selected="selected"':''; ?>>30</option>
	<option value="31"<?php echo $date[2]==31?'selected="selected"':''; ?>>31</option>
	</select>
	<select name="<?php echo $name; ?>[year]" >
	<?php
	$date = getdate();
	for ($i = 0; $i < 80; $i++)
		echo '<option value="'.($date['year']-$i).'"'.($date[0]==($date['year']-$i)?'selected="selected"':'').'>'.($date['year']-$i).'</option>';
	?>
	</select>
	<?php
}

/**
 * Creates a select HTML element.
 * @param string $name The name of the element
 * @param array $data Array of values and their displays. array('value'=>'display'[, 'value'=>'display'])
 * @param mixed $default The default value.
 * @param array $extra Array of attribute values. array('tag'=>'value'[, 'tag'=>'value'])
 */
function form_create_select($name, array $data, $default = null, array $extra=null) {
	echo "<select name=\"$name\"";
	if ($extra!=null) {
		foreach ($extra as $key => $value) {
			echo " $key=\"$value\"";
		}
	}
	echo '>'.EOL;
	if ($default != null) {
		foreach ($data as $key => $value) {
			echo TAB."<option value=\"$key\"";
			if ($key == $default) echo ' selected="selected"';
			echo ">$value</option>".EOL;
		}
	} else {
		foreach ($data as $key => $value) {
			echo TAB."<option value=\"$key\">$value</option>".EOL;
		}
	}
	echo '</select>';
}
/**
 * Creates an input field of the specified type with the specified value.
 * Type defaults to 'text'. If value is empty then it will try to find the value from the $_REQUEST super global.
 * @param string $name Name of the input element.
 * @param string $type [optional]Type of the element.
 * @param string $value [optional]Value of the element.
 */
function form_create_input($name, $type='text', $value='') {
	if (empty($value)) {
		if (isset($_REQUEST[$name])) {
			$value = $_REQUEST[$name];
		}
	}
?><input type="<?php echo $type; ?>" name="<?php echo $name; ?>" value="<?php echo $value; ?>" /><?php
}
function form_create_phone($name, $area='', $prefix='', $line='') {
	$phone = form_get($name);
	if (empty($area)) {
		if (isset($phone['area'])) {
			$area = $phone['area'];
		}
	}
	if (empty($prefix)) {
		if (isset($phone['prefix'])) {
			$prefix = $phone['prefix'];
		}
	}
	if (empty($line)) {
		if (isset($phone['line'])) {
			$line = $phone['line'];
		}
	}
?>(<input type="text" name="<?php echo $name; ?>[area]" value="<?php echo $area; ?>" maxlength="3" />)<input type="text" name="<?php echo $name; ?>[prefix]" value="<?php echo $prefix; ?>" maxlength="3" />-<input type="text" name="<?php echo $name; ?>[line]" value="<?php echo $line; ?>" maxlength="4" /><?php
}
function form_phone_tostr(array $phone_ary) {
	return $phone_ary['area'].'-'.$phone_ary['prefix'].'-'.$phone_ary['line'];
}
function form_text($name, $value=null, array $extra = null) {
	if ($value==null) $value=form_get($name);
	echo '<input type="text" name="'.$name.'" value="'.$value.'" ';
	foreach ($ele as $key => $value) {
		echo $key.'="'.$value.'" ';
	}
	echo '/>'.EOL;
}
function form_text_labeled($name, $id, $label, $value=null, array $extra=null) {
	if ($value==null) $value=form_get($name);
	echo '<label for="'.$id.'">'.$label.'</label>';
	echo '<input type="text" name="'.$name.'" value="'.$value.'" ';
	foreach ($ele as $key => $value) {
		echo $key.'="'.$value.'" ';
	}
	echo '/>'.EOL;
}
?>